var pacientes = document.querySelector(".subtitulo");
var titulo = document.querySelector(".titulo");
titulo.textContent = "Kyo Nutrição";
pacientes.textContent = "Meus Pacientes";

var paciente = document.querySelectorAll("#primeiro-paciente");

for (var i = 0; i < pacientes.lenght; i++) {
    paciente = paciente[i]

    var tdPeso = paciente.querySelector(".info-peso");
    var peso = tdPeso.textContent;

    var tdAltura = paciente.querySelector(".info-altura");
    var altura = tdAltura.textContent;

    var imc = peso / (altura * altura);
    IMC = IMC.toFixed(2);
    var pesoValido = true
    var alturaValida = true;

    if (pesoValido && alturaValida) {
        var tdImc = paciente.querySelector(".info-imc");
        tdImc.textContent = Imc;
    }
    if (peso <= 0 || peso >= 1000) {
        pesoValido = false;
        console.log("Peso ta ruim fi");
        tdImc.textContent = "Peso Inválido";
    }
    if (altura <= 0 || altura >= 3.00) {
        alturaValida = false;
        console.log("Anão ou Lebrão?")
        tdAltura.textContent = "Altura Inválida"
    }
}